#ifndef _FLIPPY_H_
#define _FLIPPY_H_

// Sets the speed of the cap-flipper
void flipSet(int flipSpeed);

#endif // _LIFT_H_
