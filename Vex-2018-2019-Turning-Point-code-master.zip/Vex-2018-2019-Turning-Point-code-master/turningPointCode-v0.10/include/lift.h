#ifndef _LIFT_H_
#define _LIFT_H_

// Sets the speed of the lift
void liftSet(int liftSpeed);

#endif // _LIFT_H_
